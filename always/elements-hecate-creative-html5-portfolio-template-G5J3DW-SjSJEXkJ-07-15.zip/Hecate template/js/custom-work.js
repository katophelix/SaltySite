(function($) { "use strict";


	//Tooltip

	$(document).ready(function() {
	
		$(".tipped").tipper();

		
	//Project Slider
	 
	  $("#owl-image-slider").owlCarousel({
	 
		navigation : false,
		pagination: true,
		transitionStyle : "fadeUp",
		autoPlay: 4500,
		slideSpeed : 700,
		singleItem:true
	 
	  });

	 
	  $("#owl-image-slider1").owlCarousel({
	 
		navigation : false,
		pagination: true,
		transitionStyle : "fadeUp",
		autoPlay: 4500,
		slideSpeed : 700,
		singleItem:true
	 
	  });

	 
	  $("#owl-image-slider2").owlCarousel({
	 
		navigation : false,
		pagination: true,
		transitionStyle : "fadeUp",
		autoPlay: 4500,
		slideSpeed : 700,
		singleItem:true
	 
	  });
	 
	});	


	
  })(jQuery); 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 





	