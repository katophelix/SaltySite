(function($) { "use strict";


	//Tooltip

	$(document).ready(function() {
	
		$(".tipped").tipper();

		
	//Text slider home
	 
	  $("#owl-text-home").owlCarousel({
	 
		navigation : false,
		pagination: false,
		transitionStyle : "fadeUp",
		autoPlay: 4500,
		slideSpeed : 700,
		singleItem:true
	 
	  });
	 
	});	
 
  })(jQuery); 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 





	